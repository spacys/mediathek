#!/usr/bin/env python
# -*- coding: utf-8 -*-

import http.cookiejar as cookielib
from resources.lib.singleton import Singleton

class AMaccess( Singleton ):
    """
    Predefined variables to store user connection information
    """
    CSRF_TOKEN      = CSRF_TS       = CSRF_RND  = ACCESSTOKEN = None
    DEVICEID        = CUSTOMERID    = MARKETPLACEID = None
    DEVICETYPE      = ACCESSTYPE    = APPVERSION = None
    MUSICTERRITORY  = CUSTOMERLANG  = LOCALE = REGION =  USERTLD = None
    USEREMAIL       = USERPASSWORD  = None
    COOKIE = cookielib.MozillaCookieJar()

    # What is kept between two starts of Kodi. The password never is.
    STORED = ('CSRF_TOKEN', 'CSRF_TS', 'CSRF_RND', 'ACCESSTOKEN', 'DEVICEID', 'CUSTOMERID', 'MARKETPLACEID',
              'DEVICETYPE', 'ACCESSTYPE', 'APPVERSION', 'MUSICTERRITORY', 'CUSTOMERLANG', 'LOCALE', 'REGION',
              'USERTLD', 'USEREMAIL')
