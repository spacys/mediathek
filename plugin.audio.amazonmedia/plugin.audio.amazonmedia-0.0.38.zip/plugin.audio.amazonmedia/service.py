#!/usr/bin/env python
# -*- coding: utf-8 -*-
import threading
import socket
import sys
from datetime import datetime, timedelta
import xbmc
from resources.lib.NetflixCommon import NetflixCommon
from resources.lib.HttpReqHandler import HttpReqHandler

# Setup plugin
BASE_URL = sys.argv[0]
PLUGIN_HANDLE = None

class AmznService(object):
    def __init__(self):
        self.nx_common = NetflixCommon(plugin_handle=PLUGIN_HANDLE,
                                       base_url=BASE_URL)
        self.startidle = 0
        self.freq = int('0' + self.nx_common.get_setting('auto_update'))
        # pick & store a port for the MSL service
        msl_port = self.getUnusedPort()
        self.nx_common.set_setting('msl_service_port', str(msl_port))
        self.nx_common.flush_settings()
        # server defaults
        MSLTCPServer.allow_reuse_address = True
        # configure the MSL Server
        self.msl_server = MSLTCPServer(('127.0.0.1', msl_port),
                                       self.nx_common)
        self.msl_thread = threading.Thread(
            target=self.msl_server.serve_forever)
    def getUnusedPort():
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(('127.0.0.1', 0))
        _, port = sock.getsockname()
        sock.close()
        return port
    def _start_servers(self):
        self.msl_server.server_activate()
        self.msl_server.timeout = 1
        self.msl_thread.start()
    def _shutdown(self):
        self.msl_server.server_close()
        self.msl_server.shutdown()
        self.msl_thread.join()
        self.msl_server = None
        self.msl_thread = None
    def _is_idle(self):
        if self.nx_common.get_setting('wait_idle') != 'true':
            return True

        lastidle = xbmc.getGlobalIdleTime()
        if xbmc.Player().isPlaying():
            self.startidle = lastidle
        if lastidle < self.startidle:
            self.startidle = 0
        idletime = lastidle - self.startidle
        return idletime >= 300
    def run(self):
        self._start_servers()
        controller = PlaybackController(self.nx_common)
        controller.action_managers = [
            BookmarkManager(self.nx_common),
            SectionSkipper(self.nx_common),
            StreamContinuityManager(self.nx_common)
        ]
        player = xbmc.Player()
        while not controller.abortRequested():
            if self.ns_server.esn_changed():
                self.msl_server.reset_msl_data()
            try:
                if player.isPlayingVideo():
                    controller.on_playback_tick()
                if self.library_update_scheduled() and self._is_idle():
                    self.update_library()
            except RuntimeError as exc:
                self.nx_common.log(
                    'RuntimeError in main loop: {}'.format(exc), xbmc.LOGERROR)
            if controller.waitForAbort(1):
                break
        self._shutdown()
if __name__ == '__main__':
    AmznService().run()
